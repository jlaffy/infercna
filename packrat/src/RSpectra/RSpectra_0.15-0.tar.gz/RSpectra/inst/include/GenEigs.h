#ifndef GENEIGS_H
#define GENEIGS_H

#ifdef __cplusplus
#include <Spectra/GenEigsSolver.h>
#include <Spectra/GenEigsRealShiftSolver.h>
#include <Spectra/GenEigsComplexShiftSolver.h>
#endif

#endif /* GENEIGS_H */
